# Copyright (c) 2025 Nikola Tesla
# Terminal program
# Processes payments from Paystack and Braintree (maybe Xoom)
# Remittance issues the payment to Terminal who processes the payments and does the deposit or withdrawal
