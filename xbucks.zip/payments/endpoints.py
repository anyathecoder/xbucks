# Copyright (c) 2025 Nikola Tesla
# Endpoints
# Tells the XBucks system how to receive deposits or make withdrawals as per the currency
# E.g. NGN, ZAR etc - Paystack (African currencies)
#   USD, EUR, GBP - Braintree (International currencies)
# One gets the sense that i have to use Xoom if Braintree doesn't support Asian or Middle Eastern currencies

