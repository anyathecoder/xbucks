# Copyright (c) 2025 Nikola Tesla
# Remittance program
# Acknowledges transactions with fiat money, stores them in the mempool and adds them to the ledger once confirmed by the consensus program
