from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
class XBucksUI(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'vertical'
        self.amount = TextInput(hint_text='Amount')
        self.fee = TextInput(hint_text='Fee Offered')
        self.add_widget(self.amount)
        self.add_widget(self.fee)
        self.add_widget(Button(text='Send', on_press=self.send_tx))
        
    def send_tx(self, instance):
        print("Transaction sent with fee:", self.fee.text)
        
class XBucksApp(App):
    def build(self):
        return XBucksUI()
    
if __name__ == '__main__':
    XBucksApp().run()
