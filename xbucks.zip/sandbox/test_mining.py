
import sys
import os
import time

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from transaction import Transaction
from mempool import Mempool
from ledger import Ledger
from miner import Miner
from account import Account
from xdns import DNS

def test_mining():
    print("Testing Mining System...")
    
    # Setup
    if not os.path.exists('./db'):
        os.makedirs('./db')
    
    # Clean DBs
    if os.path.exists('./db/mempool.bin'): os.remove('./db/mempool.bin')
    if os.path.exists('./db/ledger.data'): os.remove('./db/ledger.data')
    
    # 1. Create a transaction
    print("\n--- Step 1: Create Transaction ---")
    tx = Transaction("alice_passphrase", "bob", 100, 5, "USD", sender_account_name="alice")
    tx.submit()
    
    # Verify Mempool has it
    mp = Mempool()
    if len(mp.mempool) == 1:
        print("Mempool has 1 transaction.")
    else:
        print(f"Error: Mempool has {len(mp.mempool)}")
        return

    # 2. Mine Block
    print("\n--- Step 2: Run Miner ---")
    # Difficulty low for test (PoD params)
    miner = Miner(account_passphrase="miner_pass", account_name="miner1", difficulty=8, pod_k=1, pod_diff=4)
    block = miner.mine_block()
    
    if block:
        print("Block Successfully Mined!")
        print(f"Block Hash: {block['hash']}")
    else:
        print("Mining Failed!")
        return

    # 3. Verify Ledger
    print("\n--- Step 3: Verify Ledger ---")
    ledger = Ledger()
    last = ledger.get_last_entry()
    if last:
        print(f"Ledger Last Entry Index: {last['index']}")
        if last['hash'] == block['hash']:
            print("SUCCESS: Ledger matches mined block.")
        else:
            print("FAILURE: Ledger hash mismatch.")
            
        # Check transactions inside block
        if len(last['transactions']) == 1:
            print("SUCCESS: Block contains transaction.")
        else:
            print("FAILURE: Block empty or wrong tx count.")
    else:
        print("FAILURE: Ledger is empty.")

    # 4. Verify Mempool Cleared
    print("\n--- Step 4: Verify Mempool Cleared ---")
    mp_final = Mempool()
    if len(mp_final.mempool) == 0:
        print("SUCCESS: Mempool cleared.")
    else:
         print(f"FAILURE: Mempool not cleared. Count: {len(mp_final.mempool)}")

if __name__ == "__main__":
    test_mining()
