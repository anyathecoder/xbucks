
import sys
import os
import json

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from transaction import Transaction
from xdns import DNS
from mempool import Mempool
from account import Account

def test_full_flow():
    print("Testing Full Flow...")
    
    # 1. Setup DNS
    print("Step 1: Registering 'bob' in DNS")
    dns = DNS()
    # Create a real account for Bob to get a valid public key
    bob_account = Account("bob_passphrase", account_name="bob")
    bob_address = bob_account.identity() # Or ixan? Transaction uses receiver as string. Let's use identity (pub key PEM stripped) or IXAN.
    # Transaction.get_microformat uses self.receiver in string join.
    # self.receiver in Transaction is initialized with resolver.
    
    # Let's register 'bob' -> bob_address
    dns.register_address("bob", bob_address)
    print(f"Registered 'bob' -> {bob_address[:20]}...")

    # 2. Create Transaction using 'bob'
    print("Step 2: Creating Transaction to 'bob'")
    passphrase = "alice_passphrase"
    sender_account_name = "alice"
    amount = 50
    fees = 2
    currency = "USD"
    
    try:
        tx = Transaction(passphrase, "bob", amount, fees, currency, sender_account_name=sender_account_name)
        print("Transaction created.")
        
        # Verify receiver resolved
        if tx.receiver == bob_address:
            print("SUCCESS: Receiver resolved correctly via DNS.")
        else:
            print(f"FAILURE: Receiver resolution failed. Got: {tx.receiver[:20]}... Expected: {bob_address[:20]}...")
            
        # 3. Validate
        if tx.validate():
            print("SUCCESS: Transaction is valid.")
        else:
            print("FAILURE: Transaction is invalid.")
            
        # 4. Submit to Mempool
        print("Step 3: Submitting to Mempool")
        tx.submit()
        
        # 5. Verify persistence
        print("Step 4: Verifying Mempool Persistence")
        mp = Mempool()
        if len(mp.mempool) > 0:
            last_tx = mp.mempool[-1]
            if last_tx['recipient'] == bob_address: # microformat stores resolved address
                print("SUCCESS: Transaction found in Mempool with correct recipient.")
            else:
                 print(f"FAILURE: Mempool recipient mismatch. Got: {last_tx['recipient'][:20]}")
        else:
            print("FAILURE: Mempool is empty.")
            
    except Exception as e:
        print(f"An error occurred: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_full_flow()
