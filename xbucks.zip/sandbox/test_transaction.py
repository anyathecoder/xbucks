
import sys
import os

# Add parent directory to path to import modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from transaction import Transaction

def test_transaction():
    print("Testing Transaction...")
    passphrase = "test_passphrase"
    receiver = "receiver_address_123"
    amount = 50
    fees = 10
    currency = "USD"
    
    try:
        tx = Transaction(passphrase, receiver, amount, fees, currency, sender_account_name="test_user")
        print("Transaction created.")
        print(f"Signature: {tx.signature}")
        
        is_valid = tx.validate()
        print(f"Is valid: {is_valid}")
        
        if is_valid:
            print("SUCCESS: Transaction is valid.")
        else:
            print("FAILURE: Transaction is invalid.")
            
    except Exception as e:
        print(f"An error occurred: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_transaction()
