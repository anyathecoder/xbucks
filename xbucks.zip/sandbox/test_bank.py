
import sys
import os
import time

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from bank import Bank, DEX
from accountmanager import AccountManager

def test_bank():
    print("Testing Bank & DEX System...")
    
    # Setup AccountManager (mock user)
    am = AccountManager('test_bank_user', default='USD')
    bank = Bank(am)
    
    # 1. Deposit Fiat
    print("\n--- Step 1: Deposit Fiat ---")
    bank.deposit_fiat(5000, "USD", {'number': '1234'})
    
    bal = am.get_balance("USD")
    print(f"USD Balance: {bal}")
    if float(bal[0]) >= 5000:
        print("SUCCESS: Deposit works.")
    else:
        print("FAILURE: Deposit failed.")

    # 2. Convert to USDT
    print("\n--- Step 2: Convert to USDT ---")
    usdt_got = bank.convert_fiat_to_usdt("USD", 1000)
    
    bal_usd = am.get_balance("USD")[0]
    bal_usdt = am.get_balance("USDT")[0]
    
    print(f"New USD Balance: {bal_usd}")
    print(f"New USDT Balance: {bal_usdt}")
    
    if float(bal_usdt) >= 990: # Allowing for rate fluctuation
        print(f"SUCCESS: Conversion worked (Got {usdt_got} USDT)")
    else:
        print("FAILURE: Conversion failed.")

    # 3. Create USDT Wallet
    print("\n--- Step 3: USDT Wallet ---")
    addr = bank.get_usdt_wallet("test_bank_user")
    print(f"Generated USDT Address: {addr}")
    if addr.startswith("0x"):
        print("SUCCESS: Address generated.")
    else:
        print("FAILURE: Bad address format.")

    # 4. Savings
    print("\n--- Step 4: Savings ---")
    bank.deposit_savings(500, "USDT", lock_days=30)
    savings = bank.get_savings_balance()
    print(f"Savings Entry: {savings}")
    
    bal_usdt_after = am.get_balance("USDT")[0]
    print(f"USDT Balance after savings: {bal_usdt_after}")
    
    if len(savings) > 0 and savings[0][1] == 500:
        print("SUCCESS: Savings locked.")
    else:
        print("FAILURE: Savings failed.")

    # 5. DEX Swap (NGN -> USD)
    print("\n--- Step 5: DEX Swap NGN -> USD ---")
    # First get some NGN
    bank.deposit_fiat(10000, "NGN", {})
    
    try:
        got, rate = DEX.swap(am, "NGN", "USD", 5000)
        print(f"Swapped 5000 NGN @ {rate} -> {got} USD")
        
        bal_ngn = am.get_balance("NGN")[0]
        bal_usd_final = am.get_balance("USD")[0]
        
        print(f"Final NGN: {bal_ngn}")
        print(f"Final USD: {bal_usd_final}")
        
        if float(bal_ngn) == 5000:
            print("SUCCESS: DEX Swap worked.")
        else:
            print("FAILURE: DEX Balance mismatch.")
            
    except Exception as e:
        print(f"FAILURE: DEX Swap Error: {e}")

if __name__ == "__main__":
    test_bank()
