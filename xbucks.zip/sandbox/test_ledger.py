
import sys
import os

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ledger import Ledger

def test_ledger():
    print("Testing Ledger...")
    
    # Ensure db directory exists
    if not os.path.exists('./db'):
        os.makedirs('./db')
        
    # Clear existing ledger for test
    if os.path.exists('./db/ledger.data'):
        os.remove('./db/ledger.data')

    ledger = Ledger()
    
    dummy_entry = {
        'id': 1,
        'data': 'Genesis Block'
    }
    
    print("Writing entry to ledger...")
    ledger.write(dummy_entry)
    
    print("Reloading Ledger...")
    ledger2 = Ledger()
    
    if len(ledger2.ledger) == 1:
        print("Reloaded ledger has 1 entry.")
        entry = ledger2.get_last_entry()
        print(f"Entry: {entry}")
        if entry['data'] == 'Genesis Block':
            print("SUCCESS: Ledger entry verified.")
        else:
            print("FAILURE: Ledger data mismatch.")
    else:
        print(f"FAILURE: Ledger has {len(ledger2.ledger)} entries. Expected 1.")

if __name__ == "__main__":
    test_ledger()
