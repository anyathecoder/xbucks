
import sys
import os
import json

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from mempool import Mempool

def test_mempool():
    print("Testing Mempool...")
    
    # Ensure db directory exists
    if not os.path.exists('./db'):
        os.makedirs('./db')
        
    # Clear existing mempool for test
    if os.path.exists('./db/mempool.bin'):
        os.remove('./db/mempool.bin')

    mp = Mempool()
    
    # Create a dummy transaction object (mimicking the structure expected by parse_tx)
    # parse_tx expects a dict with 'mc' (microformat) and 'signature'
    # mc string: sender|receiver|money_json|time|fees
    
    money_data = {'amount': '10', 'currency': 'USD', 'owner': 'sender_addr'}
    money_json = json.dumps(money_data)
    
    mc_str = f"sender_addr|receiver_addr|{money_json}|2025-01-01|5"
    
    dummy_tx = {
        'mc': mc_str,
        'signature': 123456789 # Mock signature
    }
    
    print("Storing transaction...")
    try:
        mp.store_tx(dummy_tx)
        print("Transaction stored.")
    except Exception as e:
        print(f"Failed to store transaction: {e}")
        return

    # Verify in-memory list
    if len(mp.mempool) == 1:
        print("In-memory mempool has 1 item.")
    else:
        print(f"In-memory mempool has {len(mp.mempool)} items. Expected 1.")

    print("Reloading Mempool from disk...")
    mp2 = Mempool()
    if len(mp2.mempool) == 1:
        print("Reloaded mempool has 1 item.")
        loaded_tx = mp2.mempool[0]
        print(f"Loaded TX: {loaded_tx}")
        if loaded_tx['sender'] == 'sender_addr':
            print("SUCCESS: Transaction data verified.")
        else:
            print("FAILURE: Transaction data mismatch.")
    else:
        print(f"Reloaded mempool has {len(mp2.mempool)} items. Expected 1.")

if __name__ == "__main__":
    test_mempool()
