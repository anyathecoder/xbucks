
import sys
import os
import time
import threading
import xmlrpc.client
import json

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from node import NodeManager, make_signature, make_message_for_rpc
from ledger import Ledger

def test_node_server():
    print("Testing Node Integration...")
    
    # Clean DB
    if os.path.exists('./db/ledger.data'): os.remove('./db/ledger.data')

    host = "127.0.0.1"
    port = 9988 # use different port than default to avoid conflict if running
    secret = "test_secret"
    
    # Start Node
    node = NodeManager(host, port, secret)
    t = threading.Thread(target=node.start)
    t.daemon = True
    t.start()
    
    print("Node started in background...")
    time.sleep(2) # Wait for startup
    
    try:
        # Connect client
        url = f"http://{host}:{port}/"
        proxy = xmlrpc.client.ServerProxy(url)
        
        # 1. Test receive_block
        print("\n--- Step 1: Send Block via RPC ---")
        block = {
            'index': 1,
            'data': 'RPC Block Test',
            'hash': 'aabbcc'
        }
        block_json = json.dumps(block)
        
        timestamp = str(time.time())
        nonce = "12345"
        msg = make_message_for_rpc(timestamp, nonce, block_json)
        sig = make_signature(secret, msg)
        
        res = proxy.receive_block(block_json, timestamp, nonce, sig)
        print(f"receive_block Response: {res}")
        
        if res.get('success'):
            print("SUCCESS: Block accepted via RPC.")
        else:
             print(f"FAILURE: Block rejected. Reason: {res.get('reason')}")
             
        # 2. Verify Ledger persistence
        print("\n--- Step 2: Verify Local Ledger ---")
        l = Ledger()
        last = l.get_last_entry()
        if last and last.get('hash') == 'aabbcc':
             print("SUCCESS: Ledger updated locally.")
        else:
             print("FAILURE: Ledger not updated.")

        # 3. Test get_ledger
        print("\n--- Step 3: Get Ledger via RPC ---")
        msg = make_message_for_rpc(timestamp, nonce, "")  # payload empty for get
        sig = make_signature(secret, msg)
        
        b64_ledger = proxy.get_ledger(timestamp, nonce, sig)
        print(f"Got Ledger size: {len(b64_ledger)}")
        
        if len(b64_ledger) > 0:
            print("SUCCESS: Received ledger data.")
        else:
            print("FAILURE: Received empty data.")

    except Exception as e:
        print(f"Test Failed: {e}")
        import traceback
        traceback.print_exc()
    finally:
        print("\nStopping Node...")
        node.stop()

if __name__ == "__main__":
    test_node_server()
