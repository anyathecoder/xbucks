This is a dummy folder where all code that ChatGPT will repair are stored. 

We are using ChatGPT to create this code so that it will be very clean!

PS: I wil write a code for a MySQL engine for the app
