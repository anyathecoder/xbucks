
import sys
import os
import threading
import time
from kivy.app import App
from kivy.lang import Builder
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.core.window import Window
from kivy.properties import ObjectProperty, StringProperty, BooleanProperty
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.popup import Popup
from kivy.uix.label import Label
from kivy.clock import Clock

# Add parent directory to path to locate backend modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from accountmanager import AccountManager
from account import Account
from bank import Bank, DEX
from transaction import Transaction
from external_apis import YellowCardAPI, RapydAPI, UniswapService

# Window Setup
Window.size = (1240, 850)
Window.clearcolor = (0.95, 0.97, 0.99, 1)

class MainWindow(BoxLayout):
    pass

class DashboardScreen(Screen):
    def on_enter(self):
        try:
            self.ids.balance_label.text = "$10,500.00"
        except: pass

class SendInternalScreen(Screen): pass
class SendGlobalScreen(Screen): pass
class DepositScreen(Screen): pass
class WithdrawScreen(Screen): pass
class MineScreen(Screen): pass
class DexScreen(Screen): pass
class SaveScreen(Screen): pass

class XBucksApp(App):
    # Production Level Controllers
    account_manager = ObjectProperty(None)
    bank = ObjectProperty(None)
    yc = ObjectProperty(None)
    rapyd = ObjectProperty(None)
    uniswap = ObjectProperty(None)
    
    is_mining = BooleanProperty(False)
    passphrase = StringProperty("production_passphrase")
    user_name = StringProperty("Kathryn")

    def build(self):
        # 1. Load Style explicitly (Renamed to prevent auto-loading duplicates)
        # Kivy automatically loads xbucks.kv if the App class is XBucksApp.
        # By using xbucks_style.kv and explicit Builder.load_file, we control it.
        try:
            Builder.load_file('ui/xbucks_style.kv')
        except Exception as e:
            print(f"[Error] KV Load failed: {e}")
        
        # 2. Initialize Core Services
        try:
            self.account_manager = AccountManager(self.passphrase)
            self.bank = Bank(self.account_manager)
            self.yc = YellowCardAPI()
            self.rapyd = RapydAPI()
            self.uniswap = UniswapService()
            print("[System] Production stack online.")
        except Exception as e:
            print(f"[Error] Backend init failed: {e}")
        
        # 3. Return SINGLE instance of root
        # This is the only place we return a widget.
        return MainWindow()

    # --- Feature Logic ---

    def send_internal(self, target, amount):
        """Send money between XBucks accounts."""
        try:
            amt = float(amount)
            tx = Transaction(self.passphrase, target, amt, 1, "USDT", sender_account_name=self.user_name)
            tx.submit()
            self.show_popup("Success", f"Sent {amt} USDT to {target}")
        except Exception as e:
            self.show_popup("Send Error", str(e))

    def rapyd_send(self, acc, amount):
        """Global Bank Transfer via Rapyd."""
        try:
            res = self.rapyd.create_payout(float(amount), "USD", acc)
            self.show_popup("Rapyd Payout", f"Status: {res['status']}\nTracking: {res['id']}")
        except Exception as e:
            self.show_popup("Rapyd Error", str(e))

    def yc_deposit(self, amount):
        """Deposit via YellowCard."""
        try:
            res = self.yc.initiate_on_ramp(float(amount), "NGN")
            self.show_popup("Payment Instructions", res['instructions'])
        except Exception as e:
            self.show_popup("YC Error", str(e))

    def yc_withdraw(self, amount, details):
        """Withdraw via YellowCard."""
        try:
            res = self.yc.initiate_off_ramp(float(amount), details)
            self.show_popup("Withdrawal Success", f"TxID: {res['id']}")
        except Exception as e:
            self.show_popup("YC Error", str(e))

    def uniswap_swap(self, tin, tout, amt):
        """DEX Swap via Uniswap."""
        try:
            res = self.uniswap.swap_tokens(float(amt), tin, tout, "0xUSER_WALLET")
            self.show_popup("Uniswap Success", f"Received {res['amount_received']:.4f} {tout}\nHash: {res['tx_hash'][:16]}...")
        except Exception as e:
            self.show_popup("DEX Error", str(e))

    def bank_save(self, amount):
        """Locked Savings."""
        try:
            if self.bank.deposit_savings(float(amount), "USDT"):
                self.show_popup("XBucks Savings", "Funds locked for 30 days @ 5% APY.")
        except Exception as e:
            self.show_popup("Savings Error", str(e))

    # --- Mining Logic ---

    def toggle_mining(self):
        self.is_mining = not self.is_mining
        mine_screen = self.root.ids.sm.get_screen('mine')
        if self.is_mining:
            mine_screen.ids.mine_status.text = "Status: MINING ACTIVE (PoD)"
            threading.Thread(target=self._mining_thread, daemon=True).start()
        else:
            mine_screen.ids.mine_status.text = "Status: Idle"

    def _mining_thread(self):
        while self.is_mining:
            # Simulated Work
            time.sleep(2)
            print("[Miner] Solving block...")

    def show_popup(self, title, content):
        popup = Popup(title=title, content=Label(text=content), size_hint=(None, None), size=(500, 300))
        popup.open()

if __name__ == '__main__':
    XBucksApp().run()
